// SIMPLE client-side app using localStorage
// Data keys: users, pcs, printers, routers, issues
// Admin default: email='admin', password='Admin123*'

/* ------------ Utilities ------------ */
const uid = () => 'id_' + Math.random().toString(36).slice(2,9);
const nowISO = ()=> new Date().toISOString();
const load = key => { try { return JSON.parse(localStorage.getItem(key) || '[]') } catch(e){ return [] } };
const save = (key, arr) => localStorage.setItem(key, JSON.stringify(arr));

/* ------------ ensure admin ------------ */
(function ensureAdmin(){
  const users = load('users');
  if(!users.find(u=>u.email==='admin')){
    users.push({ email:'admin', mobile:'', officeId:'ADMIN', officeName:'Admin', password:'Admin123*', isAdmin:true });
    save('users', users);
  }
})();

/* ------------ state ------------ */
let currentUser = null; // {email,...}

/* ------------ DOM shortcuts ------------ */
const sideMenu = document.getElementById('sideMenu');
const menuToggle = document.getElementById('menuToggle');
const menuClose = document.getElementById('menuClose');
const whoami = document.getElementById('whoami');
const authModal = document.getElementById('authModal');
const btnLoginTop = document.getElementById('btnLoginTop');

/* ------------ init listeners ------------ */
menuToggle.addEventListener('click', ()=> sideMenu.classList.add('open'));
menuClose.addEventListener('click', ()=> sideMenu.classList.remove('open'));

/* ------------ Navigation ------------ */
function showSection(id){
  // Only dashboard is visible for anonymous users
  const sections = ['dashboard','add','myData','report','search','issues','adminAddData','adminUsers'];
  sections.forEach(s => document.getElementById(s).classList.add('hidden'));
  // check login for protected sections
  const protectedSections = ['add','myData','report','search','issues','adminAddData','adminUsers'];
  if(!currentUser && protectedSections.includes(id)){
    alert('Please login/register to access this section.');
    document.getElementById('dashboard').classList.remove('hidden');
    sideMenu.classList.remove('open');
    return;
  }
  // admin-only checks
  if(['adminAddData','adminUsers'].includes(id) && (!currentUser || !currentUser.isAdmin)){
    alert('Admin only area. Login as Admin.');
    document.getElementById('dashboard').classList.remove('hidden');
    sideMenu.classList.remove('open');
    return;
  }
  document.getElementById(id).classList.remove('hidden');
  sideMenu.classList.remove('open');
  // contextual render
  if(id==='add') renderAddSection();
  if(id==='myData') renderMyDevices();
  if(id==='report') renderReportForm();
  if(id==='search') renderSearchOptions();
  if(id==='issues') renderIssuesList();
  if(id==='adminAddData') adminReloadList();
  if(id==='adminUsers') renderAdminUsers();
}

/* ------------ Auth Modal ------------ */
function openAuthModal(){ authModal.classList.remove('hidden'); }
function closeAuthModal(){ authModal.classList.add('hidden'); }

/* ------------ Register/Login ------------ */
function register(){
  const email = document.getElementById('regEmail').value.trim().toLowerCase();
  const mobile = document.getElementById('regMobile').value.trim();
  const officeId = document.getElementById('regOfficeId').value.trim();
  const officeName = document.getElementById('regOfficeName').value.trim();
  if(!email||!mobile||!officeId||!officeName){ alert('Fill all registration fields'); return; }
  const users = load('users');
  if(users.find(u=>u.email===email)){ alert('Email already registered'); return; }
  users.push({ email, mobile, officeId, officeName, password:'', isAdmin:false });
  save('users', users);
  alert('Registered. You can login with your email (no password required for demo).');
  closeAuthModal();
}

function login(){
  const email = document.getElementById('loginEmail').value.trim().toLowerCase();
  const pass = document.getElementById('loginPass').value;
  const users = load('users');
  const user = users.find(u=>u.email===email);
  if(!user){ alert('User not found. Please register.'); return; }
  if(user.isAdmin){
    if(pass !== user.password){ alert('Admin: wrong password'); return; }
  }
  // non-admin allowed to login without password for this demo
  currentUser = user;
  whoami.innerText = (user.email==='admin'?'Admin':'Logged: '+user.email);
  closeAuthModal();
  renderAll();
}

/* ------------ Logout ------------ */
function logout(){
  currentUser = null;
  whoami.innerText = 'Not logged in';
  renderAll();
}

/* small logout button in future can call this */

/* ------------ Render / Counters ------------ */
function renderAll(){
  document.getElementById('countPC').innerText = load('pcs').length;
  document.getElementById('countPrinter').innerText = load('printers').length;
  document.getElementById('countRouter').innerText = load('routers').length;
  // update UI elements visibility
  document.getElementById('btnLoginTop').style.display = currentUser ? 'none' : 'inline-block';
  // admin buttons enable/disable
  const adminBtns = ['adminAddDataBtn','userMgmtBtn'];
  adminBtns.forEach(id => {
    const el = document.getElementById(id);
    if(!el) return;
    if(currentUser && currentUser.isAdmin){
      el.disabled = false; el.style.opacity = 1;
    } else { el.disabled = false; /* keep visible but protected on click */ }
  });
}

/* animate counts (simple) */
function animateCounts(){
  const targets = {pc: load('pcs').length, printer: load('printers').length, router: load('routers').length};
  Object.entries(targets).forEach(([k,v])=>{
    const el = document.getElementById('count'+(k==='pc'?'PC':k==='printer'?'Printer':'Router'));
    if(!el) return;
    el.innerText = v;
  });
}

/* ------------ Card click shortcut ------------ */
function cardClick(type){
  if(type==='pc') showSection('myData');
  if(type==='printer') showSection('myData');
  if(type==='router') showSection('myData');
}

/* ------------ Add Section (user forms) ------------ */
document.getElementById('loadFormBtn').addEventListener('click', renderAddSection);

function renderAddSection(){
  if(!currentUser){ alert('Login to add devices.'); return; }
  const t = document.getElementById('addType').value;
  const c = document.getElementById('addFormContainer');
  c.innerHTML = '';
  if(t==='pc') c.innerHTML = pcFormHTML();
  if(t==='printer') c.innerHTML = printerFormHTML();
  if(t==='router') c.innerHTML = routerFormHTML();
}

function pcFormHTML(){
  return `
    <div class="panel">
      <h4>Add PC</h4>
      <div class="form-grid">
        <label>Branch name<input id="pc_branch"></label>
        <label>Company<input id="pc_company"></label>
        <label>CPU serial no.<input id="pc_cpuSN"></label>
        <label>Motherboard<input id="pc_mb"></label>
        <label>Processor<input id="pc_processor"></label>
        <label>RAM<input id="pc_ram"></label>
        <label>Hard disk<input id="pc_hdd"></label>
        <label>OS<input id="pc_os"></label>
        <label>IP<input id="pc_ip"></label>
        <label>Port no.<input id="pc_port" type="number"></label>
        <label>Installation date<input id="pc_inst" type="date"></label>
        <label>Warranty<input id="pc_warranty"></label>
        <label>AMC / Past repair history<textarea id="pc_amc"></textarea></label>
        <label>Any issue<textarea id="pc_issue"></textarea></label>
      </div>
      <div style="margin-top:8px"><button class="primary-btn" onclick="savePC()">Save PC</button></div>
    </div>`;
}

function printerFormHTML(){
  return `
    <div class="panel">
      <h4>Add Printer</h4>
      <div class="form-grid">
        <label>Type
          <select id="printer_type">
            <option>Passbook printer</option>
            <option>Dot matrix</option>
            <option>Thermal</option>
            <option>Laser</option>
          </select>
        </label>
        <label>Branch name<input id="printer_branch"></label>
        <label>Printer Name<input id="printer_name"></label>
        <label>Company<input id="printer_company"></label>
        <label>Printer SL no.<input id="printer_sl"></label>
        <label>Printer Installation Date<input id="printer_inst" type="date"></label>
        <label>Warranty<input id="printer_warranty"></label>
        <label>AMC / Repair Date<input id="printer_amc" type="date"></label>
        <label>Any issue<textarea id="printer_issue"></textarea></label>
      </div>
      <div style="margin-top:8px"><button class="primary-btn" onclick="savePrinter()">Save Printer</button></div>
    </div>`;
}

function routerFormHTML(){
  return `
    <div class="panel">
      <h4>Add Router</h4>
      <div class="form-grid">
        <label>Router Company<input id="router_company"></label>
        <label>Router SL no.<input id="router_sl"></label>
        <label>No. of Ports<input id="router_ports" type="number"></label>
        <label>Any repair / Notes<textarea id="router_issue"></textarea></label>
      </div>
      <div style="margin-top:8px"><button class="primary-btn" onclick="saveRouter()">Save Router</button></div>
    </div>`;
}

/* ------------ Save device functions ------------ */
function savePC(){
  if(!currentUser){ alert('Login to add PC'); return; }
  const obj = {
    id: uid(), ownerEmail: currentUser.email, officeId: currentUser.officeId, officeName: currentUser.officeName,
    branch: document.getElementById('pc_branch').value || '',
    company: document.getElementById('pc_company').value || '',
    cpuSN: document.getElementById('pc_cpuSN').value || '',
    motherboard: document.getElementById('pc_mb').value || '',
    processor: document.getElementById('pc_processor').value || '',
    ram: document.getElementById('pc_ram').value || '',
    hdd: document.getElementById('pc_hdd').value || '',
    os: document.getElementById('pc_os').value || '',
    ip: document.getElementById('pc_ip').value || '',
    port: document.getElementById('pc_port').value || '',
    installDate: document.getElementById('pc_inst').value || '',
    warranty: document.getElementById('pc_warranty').value || '',
    amc: document.getElementById('pc_amc').value || '',
    issues: document.getElementById('pc_issue').value || '',
    createdAt: nowISO()
  };
  const arr = load('pcs'); arr.push(obj); save('pcs', arr);
  alert('PC saved'); renderAll(); showSection('myData');
}

function savePrinter(){
  if(!currentUser){ alert('Login to add Printer'); return; }
  const obj = {
    id: uid(), ownerEmail: currentUser.email, officeId: currentUser.officeId, officeName: currentUser.officeName,
    type: document.getElementById('printer_type').value || '',
    branch: document.getElementById('printer_branch').value || '',
    name: document.getElementById('printer_name').value || '',
    company: document.getElementById('printer_company').value || '',
    sl: document.getElementById('printer_sl').value || '',
    installDate: document.getElementById('printer_inst').value || '',
    warranty: document.getElementById('printer_warranty').value || '',
    amc: document.getElementById('printer_amc').value || '',
    issues: document.getElementById('printer_issue').value || '',
    createdAt: nowISO()
  };
  const arr = load('printers'); arr.push(obj); save('printers', arr);
  alert('Printer saved'); renderAll(); showSection('myData');
}

function saveRouter(){
  if(!currentUser){ alert('Login to add Router'); return; }
  const obj = {
    id: uid(), ownerEmail: currentUser.email, officeId: currentUser.officeId, officeName: currentUser.officeName,
    company: document.getElementById('router_company').value || '',
    sl: document.getElementById('router_sl').value || '',
    ports: document.getElementById('router_ports').value || '',
    issues: document.getElementById('router_issue').value || '',
    createdAt: nowISO()
  };
  const arr = load('routers'); arr.push(obj); save('routers', arr);
  alert('Router saved'); renderAll(); showSection('myData');
}

/* ------------ My Devices view ------------ */
function renderMyDevices(){
  const container = document.getElementById('myDevicesList');
  container.innerHTML = '';
  if(!currentUser){ container.innerHTML = '<div class="muted">Login to view your devices.</div>'; return; }

  const pcs = load('pcs').filter(p => p.ownerEmail === currentUser.email);
  const printers = load('printers').filter(p => p.ownerEmail === currentUser.email);
  const routers = load('routers').filter(r => r.ownerEmail === currentUser.email);

  if(pcs.length){
    container.innerHTML += `<h4>PCs (${pcs.length})</h4>` + pcs.map(p => deviceCardHTML(p,'pc')).join('');
  }
  if(printers.length){
    container.innerHTML += `<h4>Printers (${printers.length})</h4>` + printers.map(p => deviceCardHTML(p,'printer')).join('');
  }
  if(routers.length){
    container.innerHTML += `<h4>Routers (${routers.length})</h4>` + routers.map(r => deviceCardHTML(r,'router')).join('');
  }
  if(!pcs.length && !printers.length && !routers.length){
    container.innerHTML = '<div class="muted">No devices added yet.</div>';
  }
}

function deviceCardHTML(item,type){
  const main = (type==='pc')?`CPU SN: ${item.cpuSN || '-'} | ${item.processor || ''}` :
               (type==='printer')?`Name: ${item.name||'-'} | SL: ${item.sl||'-'}` : `SL: ${item.sl||'-'} | Ports: ${item.ports||'-'}`;
  return `
    <div class="device-card" id="${type}_${item.id}">
      <div>
        <strong>${type.toUpperCase()}</strong>
        <div class="small-muted">${item.branch ? 'Branch: '+item.branch : item.officeName}</div>
        <div class="small-muted">${main}</div>
      </div>
      <div style="display:flex;gap:6px;align-items:center">
        <button class="secondary-btn" onclick="downloadSingle('${type}','${item.id}')">PDF</button>
      </div>
    </div>`;
}

/* ------------ Download single (simple HTML -> print) ------------ */
function downloadSingle(type,id){
  const arr = load(type==='pc'?'pcs':type==='printer'?'printers':'routers');
  const item = arr.find(x=>x.id===id);
  if(!item){ alert('Item not found'); return; }
  let html = `<h2>${type.toUpperCase()} Details</h2><table>`;
  Object.keys(item).forEach(k=> html += `<tr><td style="padding:6px;border-bottom:1px solid #eee;font-weight:700">${k}</td><td style="padding:6px;border-bottom:1px solid #eee">${String(item[k]||'')}</td></tr>`);
  html += `</table>`;
  const w = window.open('','_blank','width=800,height=900'); w.document.write(html); w.document.close(); w.print();
}

/* ------------ Report issue (simple) ------------ */
function renderReportForm(){
  const container = document.getElementById('reportArea');
  if(!currentUser){ container.innerHTML = '<div class="muted">Login to report an issue.</div>'; return; }
  const branches = getBranchesForCurrentUser();
  container.innerHTML = `
    <div class="panel">
      <label>Select Branch
        <select id="issue_branch">${branches.map(b=>`<option>${b}</option>`).join('')}</select>
      </label>
      <label>Select Device Type
        <select id="issue_type"><option value="pc">PC</option><option value="printer">Printer</option><option value="router">Router</option></select>
      </label>
      <label>Details<textarea id="issue_details"></textarea></label>
      <div style="margin-top:8px"><button class="primary-btn" onclick="submitIssue()">Submit Issue</button></div>
    </div>`;
}

function getBranchesForCurrentUser(){
  if(!currentUser) return [];
  const pcs = load('pcs').filter(p => p.ownerEmail === currentUser.email);
  const printers = load('printers').filter(p => p.ownerEmail === currentUser.email);
  const branches = new Set();
  pcs.forEach(p=> p.branch && branches.add(p.branch));
  printers.forEach(p=> p.branch && branches.add(p.branch));
  return branches.size ? Array.from(branches) : [currentUser.officeName];
}

function submitIssue(){
  const branch = document.getElementById('issue_branch').value;
  const type = document.getElementById('issue_type').value;
  const details = document.getElementById('issue_details').value.trim();
  if(!details){ alert('Describe the issue'); return; }
  const issues = load('issues'); issues.push({
    id: uid(), reporterEmail:currentUser.email, officeId:currentUser.officeId, officeName:currentUser.officeName,
    branch,type, details, status:'reported', createdAt: nowISO()
  });
  save('issues', issues);
  alert('Issue reported to Admin.');
  showSection('myData');
}

/* ------------ Search / Issues (simple views) ------------ */
function renderSearchOptions(){
  const users = load('users');
  const officeNames = [...new Set(users.map(u=>u.officeName))];
  const container = document.getElementById('searchArea');
  container.innerHTML = `
    <div class="form-row"><label>Select Office
      <select id="searchOffice">${officeNames.map(o=>`<option>${o}</option>`).join('')}</select>
    </label>
    <label>Select Branch
      <select id="searchBranch"><option>All</option></select>
    </label></div>
    <div id="searchResults"></div>
  `;
  const so = document.getElementById('searchOffice');
  so.addEventListener('change', ()=> populateBranchesForOffice(so.value));
  if(officeNames.length) populateBranchesForOffice(officeNames[0]);
}

function populateBranchesForOffice(officeName){
  const pcs = load('pcs').filter(p=>p.officeName===officeName);
  const printers = load('printers').filter(p=>p.officeName===officeName);
  const branches = new Set();
  pcs.forEach(p=>p.branch && branches.add(p.branch));
  printers.forEach(p=>p.branch && branches.add(p.branch));
  const arr = Array.from(branches);
  const sel = document.getElementById('searchBranch');
  sel.innerHTML = `<option>All</option>` + arr.map(b=>`<option>${b}</option>`).join('');
  renderSearchResult(officeName, sel.value || 'All');
  sel.addEventListener('change', ()=> renderSearchResult(officeName, sel.value));
}

function renderSearchResult(officeName, branch){
  const pcs = load('pcs').filter(p=>p.officeName===officeName && (branch==='All' || p.branch===branch));
  const printers = load('printers').filter(p=>p.officeName===officeName && (branch==='All' || p.branch===branch));
  const routers = load('routers').filter(r=>r.officeName===officeName);
  const container = document.getElementById('searchResults');
  container.innerHTML = `<div class="muted">${pcs.length} PCs | ${printers.length} Printers | ${routers.length} Routers</div>
    <div style="margin-top:8px">
      ${pcs.map(p => deviceCardHTML(p,'pc')).join('')}
      ${printers.map(p => deviceCardHTML(p,'printer')).join('')}
      ${routers.map(r => deviceCardHTML(r,'router')).join('')}
    </div>`;
}

function renderIssuesList(){
  const arr = load('issues');
  const container = document.getElementById('issuesArea');
  if(!arr.length){ container.innerHTML = '<div class="muted">No issues reported.</div>'; return; }
  container.innerHTML = arr.map(i=>`
    <div class="panel">
      <strong>${i.officeName} / ${i.branch} (${i.type})</strong>
      <div class="small-muted">${i.createdAt} — status: ${i.status}</div>
      <div style="margin-top:8px">${i.details}</div>
    </div>`).join('');
}

/* ------------ Admin: Add/Edit/Delete Data ------------ */
function adminReloadList(){
  const type = document.getElementById('adminDataType').value;
  const container = document.getElementById('adminDataList');
  const arr = load(type);
  if(!currentUser || !currentUser.isAdmin){ container.innerHTML = '<div class="muted">Login as Admin to use these controls.</div>'; return; }
  container.innerHTML = arr.length ? arr.map(it => adminRowHTML(it, type)).join('') : '<div class="muted">No items</div>';
}

function adminRowHTML(item,type){
  const main = type==='pcs' ? `CPU SN: ${item.cpuSN||'-'}` : type==='printers' ? `Name: ${item.name||'-'}` : `SL: ${item.sl||'-'}`;
  return `
    <div class="device-card" id="adm_${type}_${item.id}">
      <div>
        <strong>${type.replace(/s$/,'').toUpperCase()}</strong>
        <div class="small-muted">${item.officeName || ''} ${item.branch ? ' / '+item.branch:''}</div>
        <div class="small-muted">${main}</div>
      </div>
      <div style="display:flex;gap:6px">
        <button class="secondary-btn" onclick="adminEdit('${type}','${item.id}')">Edit</button>
        <button class="secondary-btn" onclick="adminDelete('${type}','${item.id}')">Delete</button>
      </div>
    </div>`;
}

function adminEdit(type,id){
  // For simplicity show a prompt-based editor for admin (can be replaced by full form)
  const arr = load(type);
  const it = arr.find(x=>x.id===id);
  if(!it){ alert('Not found'); return; }
  // We'll allow editing only a few fields quickly
  if(type==='pcs'){
    it.cpuSN = prompt('CPU Serial No', it.cpuSN||'') || it.cpuSN;
    it.processor = prompt('Processor', it.processor||'') || it.processor;
    it.branch = prompt('Branch', it.branch||'') || it.branch;
  } else if(type==='printers'){
    it.name = prompt('Printer Name', it.name||'') || it.name;
    it.sl = prompt('Serial No', it.sl||'') || it.sl;
    it.branch = prompt('Branch', it.branch||'') || it.branch;
  } else {
    it.sl = prompt('Router SL', it.sl||'') || it.sl;
    it.ports = prompt('Ports', it.ports||'') || it.ports;
  }
  save(type, arr);
  adminReloadList();
  alert('Saved');
}

function adminDelete(type,id){
  if(!confirm('Delete this item?')) return;
  let arr = load(type);
  arr = arr.filter(x=>x.id!==id);
  save(type, arr);
  adminReloadList();
}

/* ------------ Admin: Users ------------ */
function renderAdminUsers(){
  if(!currentUser || !currentUser.isAdmin){ document.getElementById('adminUsersList').innerHTML = '<div class="muted">Login as Admin</div>'; return; }
  const users = load('users');
  const container = document.getElementById('adminUsersList');
  container.innerHTML = users.map(u=>`
    <div class="device-card">
      <div>
        <strong>${u.email}</strong>
        <div class="small-muted">${u.officeName||''} (${u.officeId||''}) ${u.isAdmin? ' — Admin':''}</div>
      </div>
      <div style="display:flex;gap:8px">
        ${u.email!=='admin' ? `<button class="secondary-btn" onclick="adminRemoveUser('${u.email}')">Remove</button>` : ''}
      </div>
    </div>
  `).join('');
}

function adminRemoveUser(email){
  if(!confirm('Remove user '+email+' ?')) return;
  let users = load('users');
  users = users.filter(u=>u.email!==email);
  save('users', users);
  renderAdminUsers();
  alert('User removed');
}

/* ------------ simple download helper for admin/my devices ------------
   (We already have downloadSingle above, reuse) ------------ */

/* ------------ startup ------------ */
(function startup(){
  renderAll();
  animateCounts();
  // few UI bindings
  document.getElementById('menuToggle').addEventListener('click', ()=> sideMenu.classList.add('open'));
  document.getElementById('menuClose').addEventListener('click', ()=> sideMenu.classList.remove('open'));
  // close auth modal on background click
  document.getElementById('authModal').addEventListener('click', function(e){ if(e.target === this) closeAuthModal(); });
})();
